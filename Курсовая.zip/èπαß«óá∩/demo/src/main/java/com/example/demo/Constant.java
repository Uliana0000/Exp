package com.example.demo;

public class Constant {
    public static final String USER_TABLE = "courses";
    public static final String USERS_ID = "idCourses";
    public static final String USERS_NAME = "Name";
    public static final String USERS_STARTDATE = "StartDate";
    public static final String USERS_PEOPLE = "NumberofPeople";
    public static final String USERS_HOURS = "Hours";
    public static final String USERS_AUTHOR = "Author";


}
