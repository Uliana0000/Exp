package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.util.ResourceBundle;

public class MeController {
    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;
    @FXML
    private Button MyGitHub;
    @FXML
    private Button backtoMain;

    @FXML
    void initialize() {
        backtoMain.setOnAction(event -> {  //кнопка перехода на главную страницу
            backtoMain.getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("hello-view.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

        MyGitHub.setOnAction(event -> {  //кнопка перехода на мой гит
            try {
                Desktop.getDesktop().browse(new URI("https://github.com/Uliana0000"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            StackPane root = new StackPane();
            root.getChildren().add(MyGitHub);
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }

}
