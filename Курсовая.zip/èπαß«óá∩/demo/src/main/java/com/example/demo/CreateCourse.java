package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class CreateCourse {
    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;
    @FXML
    private Button backCourses;
    @FXML
    private TextField courseName;
    @FXML
    private TextField courseauthor;
    @FXML
    private TextField coursedate;
    @FXML
    private TextField coursehours;
    @FXML
    private TextField coursepeople;
    @FXML
    private Button createCourse;
    @FXML
    private TextArea resultOfCreate;
    @FXML
    void initialize() {
        backCourses.setOnAction(event -> {  //кнопка перехода в окно курсов
            backCourses.getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("courses1.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

        createCourse.setOnAction(event -> {     //кнопка создания курса
            CreateNewCourse();
        });
    }

    private boolean CreateNewCourse() {
        Connector dbconnector = new Connector();   //принимает информацию о  курсе
        String name = courseName.getText().trim();
        String date = coursedate.getText().trim();
        String people = coursepeople.getText().trim();
        String hours = coursehours.getText().trim();
        String author = courseauthor.getText().trim();
        //проверка информации
        if (!name.equals("") && !people.equals("") && !date.equals("") && !hours.equals("")&& !author.equals("")) {
            if (isNumeric(people) && isNumeric(hours)){
                LocalDate coursedate = LocalDate.parse(date);
                if(!coursedate.isBefore(LocalDate.now())){
                    Course course = new Course(name, date, people, hours, author);
                    try {
                        dbconnector.signUpCourse(course);   //отправляет информацию на сервер, гдесоздаётся новый курс
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    } catch (ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                    resultOfCreate.setText("Курс\nуспешно\nсоздан!");
                }
                else{
                    resultOfCreate.setText("Некорректно\nзаполнены\nданные");
                }
            }
            else{
                resultOfCreate.setText("Некорректно\nзаполнены\nданные");
            }
        }
        else{
            resultOfCreate.setText("Некорректно\nзаполнены\nданные");
        }
        return false;
    }

    public static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }

}

